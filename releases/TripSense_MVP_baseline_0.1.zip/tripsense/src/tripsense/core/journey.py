from __future__ import annotations

import json
import sqlite3
import uuid
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

from .models import RoutePlan


class JourneyStore:
    """Small persistent journey log for the MVP.

    Planning remains stateless; saving a plan creates a journey that can record
    completed stops and actual dwell time without requiring an account system.
    """

    def __init__(self, path: str | Path):
        self.path = str(path)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self) -> None:
        with closing(self._connect()) as connection, connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS journeys (
                    id TEXT PRIMARY KEY,
                    city TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    scene TEXT NOT NULL,
                    status TEXT NOT NULL,
                    plan_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS journey_stops (
                    journey_id TEXT NOT NULL,
                    position INTEGER NOT NULL,
                    poi_id TEXT NOT NULL,
                    name TEXT NOT NULL,
                    completed INTEGER NOT NULL DEFAULT 0,
                    actual_dwell_minutes REAL,
                    note TEXT,
                    PRIMARY KEY (journey_id, position),
                    FOREIGN KEY (journey_id) REFERENCES journeys(id)
                );
                """
            )

    def save(self, plan: RoutePlan) -> str:
        journey_id = uuid.uuid4().hex
        now = datetime.now(timezone.utc).isoformat()
        with closing(self._connect()) as connection, connection:
            connection.execute(
                """INSERT INTO journeys
                   (id, city, mode, scene, status, plan_json, created_at, updated_at)
                   VALUES (?, ?, ?, ?, 'planned', ?, ?, ?)""",
                (
                    journey_id,
                    plan.city,
                    plan.mode,
                    plan.scene,
                    json.dumps(plan.to_dict(), ensure_ascii=False),
                    now,
                    now,
                ),
            )
            connection.executemany(
                """INSERT INTO journey_stops
                   (journey_id, position, poi_id, name, completed)
                   VALUES (?, ?, ?, ?, ?)""",
                [
                    (journey_id, index, stop.poi_id, stop.name, int(stop.completed))
                    for index, stop in enumerate(plan.stops, start=1)
                ],
            )
        return journey_id

    def update_stop(
        self,
        journey_id: str,
        position: int,
        *,
        completed: bool | None = None,
        actual_dwell_minutes: float | None = None,
        note: str | None = None,
    ) -> dict:
        updates: list[str] = []
        values: list[object] = []
        if completed is not None:
            updates.append("completed = ?")
            values.append(int(completed))
        if actual_dwell_minutes is not None:
            if actual_dwell_minutes < 0:
                raise ValueError("actual_dwell_minutes cannot be negative")
            updates.append("actual_dwell_minutes = ?")
            values.append(float(actual_dwell_minutes))
        if note is not None:
            updates.append("note = ?")
            values.append(note)
        if not updates:
            return self.get(journey_id)

        with closing(self._connect()) as connection, connection:
            cursor = connection.execute(
                f"UPDATE journey_stops SET {', '.join(updates)} "
                "WHERE journey_id = ? AND position = ?",
                [*values, journey_id, position],
            )
            if cursor.rowcount != 1:
                raise KeyError(f"stop not found: {journey_id}/{position}")
            now = datetime.now(timezone.utc).isoformat()
            remaining = connection.execute(
                "SELECT COUNT(*) FROM journey_stops WHERE journey_id = ? AND completed = 0",
                (journey_id,),
            ).fetchone()[0]
            status = "completed" if remaining == 0 else "in_progress"
            connection.execute(
                "UPDATE journeys SET status = ?, updated_at = ? WHERE id = ?",
                (status, now, journey_id),
            )
        return self.get(journey_id)

    def get(self, journey_id: str) -> dict:
        with closing(self._connect()) as connection, connection:
            journey = connection.execute(
                "SELECT * FROM journeys WHERE id = ?", (journey_id,)
            ).fetchone()
            if journey is None:
                raise KeyError(f"journey not found: {journey_id}")
            stops = connection.execute(
                "SELECT * FROM journey_stops WHERE journey_id = ? ORDER BY position",
                (journey_id,),
            ).fetchall()
        return {
            "id": journey["id"],
            "city": journey["city"],
            "mode": journey["mode"],
            "scene": journey["scene"],
            "status": journey["status"],
            "created_at": journey["created_at"],
            "updated_at": journey["updated_at"],
            "plan": json.loads(journey["plan_json"]),
            "stops": [
                {
                    "position": row["position"],
                    "poi_id": row["poi_id"],
                    "name": row["name"],
                    "completed": bool(row["completed"]),
                    "actual_dwell_minutes": row["actual_dwell_minutes"],
                    "note": row["note"],
                }
                for row in stops
            ],
        }
