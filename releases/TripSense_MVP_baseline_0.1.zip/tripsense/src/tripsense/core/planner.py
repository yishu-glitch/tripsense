from __future__ import annotations

import heapq
from dataclasses import replace

import numpy as np
import pandas as pd

from .constraints import completion_probability, safe_time_budget
from .models import Intent, RoutePlan, Stop


ATTR_COLUMNS = [
    "cultural_score", "nature_score", "commercial_score",
    "scenic_score", "indoor_score", "edu_score",
]

MODE_WEIGHTS = {
    "relaxed": np.array([0.35, 0.85, 0.10, 0.80, 0.15, 0.20]),
    "full": np.array([0.55, 0.45, 0.10, 0.75, 0.30, 0.35]),
    "deep": np.array([1.00, 0.25, 0.05, 0.70, 0.40, 0.90]),
    "photo": np.array([0.35, 0.80, 0.10, 1.00, 0.05, 0.15]),
    "balanced": np.array([0.60, 0.60, 0.15, 0.80, 0.25, 0.40]),
}

DWELL_DEFAULTS = {
    "heritage": 75.0,
    "museum": 90.0,
    "park": 70.0,
    "attraction": 65.0,
    "culture": 60.0,
    "leisure": 45.0,
}


class RoutePlanner:
    def __init__(self, pois: pd.DataFrame, distances: dict):
        self.pois = pois.copy()
        self.pois["poi_id"] = self.pois["poi_id"].astype(str)
        self.distances = distances

    def build_candidates(self, intent: Intent, top_n: int = 180) -> list[dict]:
        """Use the city's actual distance graph and the user's scene constraints."""
        graph_ids = set(map(str, self.distances.keys()))
        frame = self.pois[self.pois["poi_id"].isin(graph_ids)].copy()
        if intent.categories:
            preferred = frame[frame["poi_type_en"].isin(intent.categories)]
            # Keep the user's explicit scene boundary whenever it can form a route.
            # A broader fallback is only justified when fewer than two stops remain.
            if len(preferred) >= 2:
                frame = preferred
        if intent.excluded_categories:
            frame = frame[~frame["poi_type_en"].isin(intent.excluded_categories)]
        frame = self._deduplicate_parent_sites(frame)
        weights = MODE_WEIGHTS[intent.mode]
        attr_score = frame[ATTR_COLUMNS].fillna(0).to_numpy(dtype=float) @ weights
        frame["_score"] = 0.55 * frame["popularity"].astype(float) + 0.45 * attr_score
        return frame.nlargest(top_n, "_score").to_dict("records")

    def plan(self, intent: Intent, *, max_stops: int = 5) -> RoutePlan:
        candidates = self.build_candidates(intent)
        if not candidates:
            raise ValueError("no route candidates after applying city and scene filters")

        budget = safe_time_budget(
            intent.available_minutes,
            intent.uncertainty_minutes,
            intent.risk_epsilon,
        )
        selected: list[dict] = []
        used_minutes = 0.0
        remaining = {str(row["poi_id"]): row for row in candidates}

        while remaining and len(selected) < max_stops:
            best: tuple[float, dict, float] | None = None
            last_id = str(selected[-1]["poi_id"]) if selected else None
            for poi in remaining.values():
                dwell = self._dwell_minutes(poi, intent)
                travel = 0.0 if last_id is None else self.travel_minutes(last_id, str(poi["poi_id"]))
                if used_minutes + travel + dwell > budget:
                    continue
                diversity_penalty = 0.12 * sum(
                    existing.get("poi_type_en") == poi.get("poi_type_en") for existing in selected
                )
                utility = float(poi["_score"]) - 0.012 * travel - diversity_penalty
                if best is None or utility > best[0]:
                    best = (utility, poi, travel)
            if best is None:
                break
            _, poi, travel = best
            poi = dict(poi)
            poi["_incoming_travel"] = travel
            selected.append(poi)
            used_minutes += travel + self._dwell_minutes(poi, intent)
            remaining.pop(str(poi["poi_id"]))

        stops: list[Stop] = []
        for index, poi in enumerate(selected):
            next_travel = None
            if index + 1 < len(selected):
                next_travel = selected[index + 1]["_incoming_travel"]
            stops.append(
                Stop(
                    poi_id=str(poi["poi_id"]),
                    name=str(poi["name"]),
                    category=str(poi.get("category_name", "")),
                    poi_type=str(poi.get("poi_type_en", "")),
                    district=str(poi.get("district", "")),
                    dwell_minutes=self._dwell_minutes(poi, intent),
                    travel_to_next_minutes=round(next_travel, 1) if next_travel else None,
                    score=round(float(poi["_score"]), 4),
                    reason=self._reason(poi, intent),
                )
            )

        planned = self.total_minutes(stops)
        reminder, voice = self._reminder(planned, intent.available_minutes)
        return RoutePlan(
            city=intent.city,
            mode=intent.mode,
            scene=intent.scene,
            stops=stops,
            available_minutes=float(intent.available_minutes),
            safe_budget_minutes=budget,
            planned_minutes=round(planned, 1),
            satisfaction_probability=completion_probability(
                planned, intent.available_minutes, intent.uncertainty_minutes
            ),
            reminder_level=reminder,
            voice=voice,
        )

    def normalize(self, plan: RoutePlan) -> RoutePlan:
        """Recalculate every adjacent edge and all derived route fields after an edit."""
        stops = [replace(stop) for stop in plan.stops]
        for index, stop in enumerate(stops):
            stop.travel_to_next_minutes = (
                self.travel_minutes(stop.poi_id, stops[index + 1].poi_id)
                if index + 1 < len(stops)
                else None
            )
        planned = self.total_minutes(stops)
        reminder, voice = self._reminder(planned, plan.available_minutes)
        return replace(
            plan,
            stops=stops,
            planned_minutes=round(planned, 1),
            satisfaction_probability=completion_probability(
                planned,
                plan.available_minutes,
                max(1.0, (plan.available_minutes - plan.safe_budget_minutes) / 1.2815515655),
            ),
            reminder_level=reminder,
            voice=voice,
        )

    def travel_minutes(self, origin: str, destination: str) -> float:
        direct = self.distances.get(str(origin), {}).get(str(destination))
        if isinstance(direct, dict):
            value = direct.get("travel_min", direct.get("walk_min"))
            if value is not None:
                return round(float(value), 1)
        estimated = self._shortest_path(str(origin), str(destination))
        return round(estimated if estimated is not None else 45.0, 1)

    def _shortest_path(self, origin: str, destination: str) -> float | None:
        if origin not in self.distances:
            return None
        queue: list[tuple[float, str]] = [(0.0, origin)]
        best = {origin: 0.0}
        while queue:
            cost, current = heapq.heappop(queue)
            if current == destination:
                return cost
            if cost > best.get(current, float("inf")):
                continue
            for neighbor, edge in self.distances.get(current, {}).items():
                weight = edge.get("travel_min", edge.get("walk_min"))
                if weight is None:
                    continue
                new_cost = cost + float(weight)
                if new_cost < best.get(str(neighbor), float("inf")):
                    best[str(neighbor)] = new_cost
                    heapq.heappush(queue, (new_cost, str(neighbor)))
        return None

    @staticmethod
    def total_minutes(stops: list[Stop]) -> float:
        return sum(stop.dwell_minutes + (stop.travel_to_next_minutes or 0.0) for stop in stops)

    @staticmethod
    def _deduplicate_parent_sites(frame: pd.DataFrame) -> pd.DataFrame:
        if "parent_site" not in frame.columns:
            return frame
        parent = frame["parent_site"].fillna("").astype(str)
        root = frame[parent.isin(["", "nan"])]
        children = frame[~parent.isin(["", "nan"])].copy()
        if children.empty:
            return frame
        children["_main"] = children["is_main_site"].astype(str).isin(["True", "true", "1"])
        children = children.sort_values(["_main", "popularity"], ascending=False)
        children = children.drop_duplicates("parent_site", keep="first").drop(columns="_main")
        return pd.concat([root, children], ignore_index=True)

    @staticmethod
    def _dwell_minutes(poi: dict, intent: Intent) -> float:
        dwell = DWELL_DEFAULTS.get(str(poi.get("poi_type_en", "")), 65.0)
        if intent.pace == "slow":
            dwell *= 1.15
        elif intent.pace == "fast":
            dwell *= 0.85
        return round(dwell, 1)

    @staticmethod
    def _reason(poi: dict, intent: Intent) -> str:
        if intent.mode == "deep":
            return "更符合你想深入了解当地文化和故事的状态"
        if intent.mode == "photo":
            return "景观表现突出，适合作为今天的拍摄重点"
        if intent.mode == "relaxed":
            return "节奏可以放慢，也方便根据现场状态随时调整"
        if intent.mode == "full":
            return "代表性和游览效率较高，适合充实地走完今天"
        return "在代表性、体验感和路线时间之间较为平衡"

    @staticmethod
    def _reminder(planned: float, available: float) -> tuple[str, str]:
        ratio = planned / max(available, 1.0)
        remaining = round(available - planned)
        if ratio <= 0.7:
            return "spacious", f"今天还留有约 {remaining} 分钟，不必急着把空白填满。"
        if ratio <= 0.9:
            return "comfortable", "这个节奏比较从容，路上想多停一会也没关系。"
        if ratio <= 1.0:
            return "tight", "时间会稍微紧一点，到现场看状态调整就好。"
        if ratio <= 1.2:
            return "over", "今天可能有点满，可以先保留最想去的地方。"
        return "overflow", "先选两三个最想去的，剩下的留作下次再来的理由。"
