from __future__ import annotations

from math import erf, sqrt
from statistics import NormalDist


def safe_time_budget(
    mean_minutes: float,
    sigma_minutes: float,
    epsilon: float = 0.1,
    *,
    wasserstein_radius: float = 0.0,
    robustness_scale: float | None = None,
) -> float:
    """Return the largest deterministic route duration with overrun risk <= epsilon.

    The uncertain quantity is the user's available time ``T_max``. For
    ``T_max ~ Normal(mean, sigma²)``, the constraint
    ``P(route_duration <= T_max) >= 1 - epsilon`` becomes
    ``route_duration <= mean + sigma * Phi^-1(epsilon)``.
    """
    if mean_minutes <= 0:
        raise ValueError("mean_minutes must be positive")
    if sigma_minutes < 0:
        raise ValueError("sigma_minutes cannot be negative")
    if not 0 < epsilon < 0.5:
        raise ValueError("epsilon must be between 0 and 0.5")
    if wasserstein_radius < 0:
        raise ValueError("wasserstein_radius cannot be negative")

    quantile = NormalDist().inv_cdf(epsilon)
    budget = mean_minutes + sigma_minutes * quantile
    if wasserstein_radius:
        scale = robustness_scale if robustness_scale is not None else max(sigma_minutes, 1.0)
        budget -= wasserstein_radius * scale
    return round(max(30.0, budget), 1)


def completion_probability(
    route_minutes: float, mean_minutes: float, sigma_minutes: float
) -> float:
    """Probability that the user's available time covers the planned route."""
    if sigma_minutes <= 0:
        return 1.0 if route_minutes <= mean_minutes else 0.0
    z = (mean_minutes - route_minutes) / sigma_minutes
    return round(0.5 * (1.0 + erf(z / sqrt(2.0))), 4)

