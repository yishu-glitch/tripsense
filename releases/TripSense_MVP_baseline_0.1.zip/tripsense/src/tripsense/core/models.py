from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class Intent:
    city: str
    utterance: str
    available_minutes: int = 240
    uncertainty_minutes: int = 30
    risk_epsilon: float = 0.1
    mode: str = "balanced"
    scene: str = "综合观光游"
    categories: list[str] = field(default_factory=lambda: ["attraction", "heritage", "park"])
    excluded_categories: list[str] = field(default_factory=list)
    mood: str = "balanced"
    pace: str = "normal"
    named_poi: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class Stop:
    poi_id: str
    name: str
    category: str
    poi_type: str
    district: str
    dwell_minutes: float
    travel_to_next_minutes: float | None
    score: float
    reason: str
    completed: bool = False
    actual_dwell_minutes: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class RoutePlan:
    city: str
    mode: str
    scene: str
    stops: list[Stop]
    available_minutes: float
    safe_budget_minutes: float
    planned_minutes: float
    satisfaction_probability: float
    reminder_level: str
    voice: str

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["stops"] = [stop.to_dict() for stop in self.stops]
        return data

