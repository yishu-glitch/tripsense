from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


SUPPORTED_CITIES = {"beijing", "shanghai"}


def project_root() -> Path:
    return Path(__file__).resolve().parents[3]


def load_city_data(city: str, data_dir: Path | None = None) -> tuple[pd.DataFrame, dict]:
    if city not in SUPPORTED_CITIES:
        raise ValueError(f"unsupported city: {city}")
    base = data_dir or project_root() / "data"
    poi_path = base / "clean" / f"poi_{city}_clean.csv"
    distance_path = base / "distance" / f"dist_{city}.json"
    pois = pd.read_csv(poi_path, dtype={"poi_id": str})
    with distance_path.open(encoding="utf-8") as stream:
        distances = json.load(stream)
    return pois, distances
