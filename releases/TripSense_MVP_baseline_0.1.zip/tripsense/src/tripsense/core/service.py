from __future__ import annotations

from pathlib import Path

from .data import load_city_data
from .intent import parse_local_intent
from .models import RoutePlan
from .planner import RoutePlanner


class TripSenseService:
    """Application service that keeps planning stable without an external LLM."""

    def __init__(self, data_dir: Path | None = None):
        self.data_dir = data_dir
        self._planners: dict[str, RoutePlanner] = {}

    def planner(self, city: str) -> RoutePlanner:
        if city not in self._planners:
            pois, distances = load_city_data(city, self.data_dir)
            self._planners[city] = RoutePlanner(pois, distances)
        return self._planners[city]

    def plan(self, text: str, city: str = "beijing") -> RoutePlan:
        intent = parse_local_intent(text, city)
        return self.planner(city).plan(intent)

