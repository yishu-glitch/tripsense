from __future__ import annotations

import re

from .models import Intent


MODE_RULES = {
    "relaxed": ["累", "放松", "放空", "随便走", "慢慢", "不赶", "悠闲", "轻松"],
    "full": ["充实", "全走", "打卡", "必去", "精力充沛", "高效", "经典"],
    "deep": ["深度", "文化", "历史", "故事", "博物馆", "古迹", "了解"],
    "photo": ["拍照", "摄影", "机位", "光线", "出片", "日落"],
}

SCENE_RULES = {
    "历史文化游": (["历史", "文化", "古迹", "博物馆", "遗址", "胡同", "古建筑"],
                   ["heritage", "museum", "culture", "attraction"]),
    "自然公园游": (["自然", "公园", "爬山", "湿地", "森林", "踏青"],
                   ["park", "attraction"]),
    "城市漫游": (["citywalk", "漫步", "街区", "随便逛", "文艺", "小众", "弄堂"],
                 ["heritage", "attraction", "culture", "park"]),
    "休闲购物游": (["购物", "逛街", "商场", "美食", "咖啡", "餐厅"],
                   ["leisure", "attraction"]),
    "亲子研学游": (["孩子", "儿童", "亲子", "带娃", "研学", "科普"],
                   ["museum", "park", "culture", "attraction"]),
}

CHINESE_NUMBERS = {
    "一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5,
    "六": 6, "七": 7, "八": 8, "九": 9, "十": 10,
}


def _parse_time_minutes(text: str) -> tuple[int, int]:
    if "半天" in text:
        return 240, 45
    if "一天" in text or "一整天" in text:
        return 480, 60

    range_match = re.search(r"([一二两三四五六七八九十\d])\s*[到至~-]\s*([一二两三四五六七八九十\d])\s*个?小时", text)
    if range_match:
        low = _to_number(range_match.group(1))
        high = _to_number(range_match.group(2))
        return round((low + high) * 30), max(20, round((high - low) * 30))

    hour_match = re.search(r"([一二两三四五六七八九十\d](?:\.\d+)?)\s*个?小时", text)
    if hour_match:
        value = _to_number(hour_match.group(1))
        sigma = 30 if any(word in text for word in ["大概", "左右", "差不多", "约"]) else 15
        return round(value * 60), sigma

    minute_match = re.search(r"(\d{2,3})\s*分钟", text)
    if minute_match:
        return int(minute_match.group(1)), 10
    return 240, 40


def _to_number(value: str) -> float:
    if value in CHINESE_NUMBERS:
        return float(CHINESE_NUMBERS[value])
    return float(value)


def parse_local_intent(text: str, city: str = "beijing") -> Intent:
    """Parse a stable offline baseline before any optional LLM enrichment."""
    normalized = text.strip().lower()
    minutes, sigma = _parse_time_minutes(normalized)

    mode_scores = {
        mode: sum(keyword in normalized for keyword in keywords)
        for mode, keywords in MODE_RULES.items()
    }
    mode = max(mode_scores, key=mode_scores.get)
    if mode_scores[mode] == 0:
        mode = "balanced"

    scene_scores = {
        scene: sum(keyword in normalized for keyword in keywords)
        for scene, (keywords, _) in SCENE_RULES.items()
    }
    scene = max(scene_scores, key=scene_scores.get)
    if scene_scores[scene] == 0:
        scene = "综合观光游"
        categories = ["attraction", "heritage", "park", "museum"]
    else:
        categories = list(SCENE_RULES[scene][1])

    mood = {
        "relaxed": "tired_or_relaxed",
        "full": "energetic",
        "deep": "curious",
        "photo": "creative",
    }.get(mode, "balanced")
    pace = "slow" if mode == "relaxed" else "fast" if mode == "full" else "normal"

    return Intent(
        city=city,
        utterance=text,
        available_minutes=minutes,
        uncertainty_minutes=sigma,
        mode=mode,
        scene=scene,
        categories=categories,
        excluded_categories=[] if scene == "休闲购物游" else ["leisure"],
        mood=mood,
        pace=pace,
    )

