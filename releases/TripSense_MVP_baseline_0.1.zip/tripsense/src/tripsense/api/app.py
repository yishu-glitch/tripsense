from __future__ import annotations

import os
from pathlib import Path

try:
    from fastapi import FastAPI
    from pydantic import BaseModel, Field
except ImportError as exc:  # pragma: no cover - clear setup error for optional dependency
    raise RuntimeError('Install the API dependencies with: pip install -e ".[api]"') from exc

from tripsense.core.journey import JourneyStore
from tripsense.core.service import TripSenseService


app = FastAPI(title="TripSense API", version="0.1.0")
service = TripSenseService()
store = JourneyStore(
    Path(os.getenv("TRIPSENSE_DB_PATH", Path.cwd() / "data" / "tripsense.db"))
)


class PlanRequest(BaseModel):
    city: str = Field(default="beijing", pattern="^(beijing|shanghai)$")
    text: str = Field(min_length=2, max_length=500)


class SaveRequest(PlanRequest):
    pass


class StopUpdateRequest(BaseModel):
    completed: bool | None = None
    actual_dwell_minutes: float | None = Field(default=None, ge=0, le=1440)
    note: str | None = Field(default=None, max_length=500)


@app.get("/api/v1/health")
def health() -> dict[str, str]:
    return {"status": "ok", "planner": "local-baseline"}


@app.post("/api/v1/routes/plan")
def plan_route(request: PlanRequest) -> dict:
    return service.plan(request.text, request.city).to_dict()


@app.post("/api/v1/journeys")
def save_journey(request: SaveRequest) -> dict[str, str]:
    plan = service.plan(request.text, request.city)
    return {"journey_id": store.save(plan)}


@app.get("/api/v1/journeys/{journey_id}")
def get_journey(journey_id: str) -> dict:
    return store.get(journey_id)


@app.patch("/api/v1/journeys/{journey_id}/stops/{position}")
def update_journey_stop(
    journey_id: str, position: int, request: StopUpdateRequest
) -> dict:
    return store.update_stop(
        journey_id,
        position,
        completed=request.completed,
        actual_dwell_minutes=request.actual_dwell_minutes,
        note=request.note,
    )

