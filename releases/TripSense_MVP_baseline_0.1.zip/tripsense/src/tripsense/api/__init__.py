"""TripSense HTTP API."""

