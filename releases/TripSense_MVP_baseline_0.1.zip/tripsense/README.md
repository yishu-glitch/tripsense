# TripSense

TripSense 是一款灵活、智能、懂用户的旅行规划与记录助手。当前版本先完成一个可复现的北京/上海规划内核，并为 Web MVP 提供稳定 API 边界。

## 产品原则

- 先理解用户此刻的状态，再生成路线。
- 时间是可以调整的建议，不是必须完成的任务。
- 用户可以随时加点、删点、替换或放慢节奏。
- 每次调整都基于当前路线继续，而不是忘掉上一轮重新开始。
- 规划完成后继续记录实际游览过程，为后续建议提供依据。

## 当前结构

```text
src/tripsense/core/   离线可运行的意图、约束、场景和路线规划内核
src/tripsense/api/    FastAPI 接口层
data/                 清洗后的北京/上海 POI、距离图、停留时间与对话数据
research/             旧实验结果与研究资产
tests/                核心公式和产品行为测试
```

## 本地验证

无需任何 API Key：

```powershell
$env:PYTHONPATH = "src"
python -m unittest discover -s tests -v
python -m tripsense.demo --city beijing --text "今天有点累，想看看历史建筑，大概四小时"
```

## 启动 API

安装 Web 依赖后：

```powershell
pip install -e ".[api]"
uvicorn tripsense.api.app:app --reload
```

核心规划器默认采用确定性本地解析，外部大模型只作为可选的语义增强层，因此断网或没有 Key 时仍可稳定演示。

