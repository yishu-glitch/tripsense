import unittest

from tripsense.core.intent import parse_local_intent


class IntentTests(unittest.TestCase):
    def test_relaxed_history_request(self):
        intent = parse_local_intent("今天有点累，想慢慢看看历史建筑，大概四小时")
        self.assertEqual(intent.mode, "relaxed")
        self.assertEqual(intent.scene, "历史文化游")
        self.assertEqual(intent.available_minutes, 240)
        self.assertIn("heritage", intent.categories)

    def test_photo_mode(self):
        intent = parse_local_intent("想拍照找机位，三小时左右")
        self.assertEqual(intent.mode, "photo")
        self.assertEqual(intent.available_minutes, 180)

    def test_hour_range(self):
        intent = parse_local_intent("大概三到四个小时，想随便逛逛")
        self.assertEqual(intent.available_minutes, 210)
        self.assertEqual(intent.scene, "城市漫游")


if __name__ == "__main__":
    unittest.main()

