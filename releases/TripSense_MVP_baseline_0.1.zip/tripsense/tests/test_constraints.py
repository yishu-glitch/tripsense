import unittest

from tripsense.core.constraints import completion_probability, safe_time_budget


class ConstraintTests(unittest.TestCase):
    def test_safe_budget_uses_lower_quantile(self):
        budget = safe_time_budget(240, 30, 0.1)
        self.assertAlmostEqual(budget, 201.6, places=1)
        self.assertAlmostEqual(completion_probability(budget, 240, 30), 0.9, places=3)

    def test_more_uncertainty_is_more_conservative(self):
        self.assertLess(safe_time_budget(240, 60, 0.1), safe_time_budget(240, 20, 0.1))

    def test_robust_radius_reduces_budget(self):
        base = safe_time_budget(240, 30, 0.1)
        robust = safe_time_budget(240, 30, 0.1, wasserstein_radius=0.2)
        self.assertLess(robust, base)


if __name__ == "__main__":
    unittest.main()

